@extends('layouts.dashboard')

@section('title', 'إدارة الطلبات')

@section('content')
<style>
/* ... كل أكواد الـ CSS تبقى كما هي ... */
/* تصميم حديث للجدول */
.modern-requests-table-container {
    background: linear-gradient(135deg, #fff 0%, #f8f9fa 100%);
    border-radius: 20px;
    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
    overflow: hidden;
    margin: 20px 0;
    border: 1px solid rgba(255,255,255,0.2);
    backdrop-filter: blur(10px);
}

.modern-requests-table {
    margin: 0;
    border: none;
    background: transparent;
    text-align: center;
}

.modern-requests-header {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 50%, #ff8c42 100%);
    position: relative;
    overflow: hidden;
}

.modern-requests-header::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.2), transparent);
    animation: shimmerHeader 3s infinite;
}

@keyframes shimmerHeader {
    0% { left: -100%; }
    100% { left: 100%; }
}

.modern-requests-th {
    color: white;
    font-weight: 600;
    text-align: center;
    padding: 20px 15px;
    border: none;
    font-size: 14px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
    position: relative;
    z-index: 1;
    width: 0%;
}

.modern-requests-th i {
    color: rgba(255,255,255,0.9);
    font-size: 16px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
}

.modern-requests-body tr {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border-bottom: 1px solid rgba(0,0,0,0.05);
    animation: rowSlideIn 0.6s ease-out;
}

@keyframes rowSlideIn {
    from {
        opacity: 0;
        transform: translateY(20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

.modern-requests-body tr:hover {
    background: linear-gradient(135deg, rgba(255,107,53,0.05) 0%, rgba(247,147,30,0.05) 100%);
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(255,107,53,0.15);
}

.modern-requests-body td {
    padding: 18px 15px;
    border: none;
    vertical-align: middle;
    font-size: 14px;
    color: #2c3e50;
    position: relative;
}

.modern-requests-body td:first-child {
    font-weight: 700;
    color: #ff6b35;
    font-size: 16px;
    text-align: center;
}

.modern-requests-body td img {
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    transition: all 0.3s ease;
    border: 2px solid rgba(255,255,255,0.8);
}

.modern-requests-body td img:hover {
    transform: scale(1.1);
    box-shadow: 0 8px 20px rgba(0,0,0,0.25);
}

.modern-requests-body .badge {
    padding: 8px 16px;
    border-radius: 25px;
    font-size: 12px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    border: 2px solid rgba(255,255,255,0.3);
}

.modern-requests-body .btn {
    border-radius: 20px;
    padding: 8px 20px;
    font-weight: 600;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border: 2px solid transparent;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    position: relative;
    overflow: hidden;
}

.modern-requests-body .btn::before {
    content: '';
    position: absolute;
    top: 0;
    left: -100%;
    width: 100%;
    height: 100%;
    background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
    transition: left 0.5s;
}

.modern-requests-body .btn:hover::before {
    left: 100%;
}

.modern-requests-body .btn-success {
    background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
    border-color: #28a745;
}

.modern-requests-body .btn-success:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(40,167,69,0.4);
    background: linear-gradient(135deg, #20c997 0%, #28a745 100%);
}

.modern-requests-body .btn-danger {
    background: linear-gradient(135deg, #dc3545 0%, #e74c3c 100%);
    border-color: #dc3545;
}

.modern-requests-body .btn-danger:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(220,53,69,0.4);
    background: linear-gradient(135deg, #e74c3c 0%, #dc3545 100%);
}

/* Modern Cards Styles */
.modern-cards-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
    gap: 25px;
    padding: 20px;
}

.modern-rent-card {
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(248, 250, 252, 0.95) 100%);
    border-radius: 20px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1), 0 1px 8px rgba(0, 0, 0, 0.06);
    border: 1px solid rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
    overflow: hidden;
    transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    position: relative;
}

.modern-rent-card::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    height: 4px;
    background: linear-gradient(90deg, #ff6b35, #f7931e, #ff6b35);
    background-size: 200% 100%;
    animation: gradientShift 3s ease-in-out infinite;
}

.modern-rent-card:hover {
    transform: translateY(-8px) scale(1.02);
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15), 0 8px 16px rgba(0, 0, 0, 0.1);
}

.modern-card-header {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
    padding: 20px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    position: relative;
    overflow: hidden;
}

.modern-card-header::before {
    content: '';
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: linear-gradient(45deg, transparent, rgba(255, 255, 255, 0.1), transparent);
    animation: shimmerFlow 3s infinite;
}

.card-header-content {
    display: flex;
    gap: 15px;
    align-items: center;
    z-index: 2;
    position: relative;
}

.card-id-badge,
.card-type-badge {
    background: rgba(255, 255, 255, 0.2);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 25px;
    padding: 8px 15px;
    display: flex;
    align-items: center;
    gap: 8px;
    color: white;
    font-weight: 600;
    font-size: 0.9rem;
    transition: all 0.3s ease;
}

.card-id-badge:hover,
.card-type-badge:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
}

.card-id-badge i,
.card-type-badge i {
    font-size: 0.8rem;
    opacity: 0.9;
}

.card-status {
    z-index: 2;
    position: relative;
}

.modern-card-body {
    padding: 25px;
}

.card-info-section {
    display: grid;
    gap: 15px;
    margin-bottom: 20px;
}

.info-item {
    display: flex;
    align-items: center;
    gap: 15px;
    padding: 15px;
    background: linear-gradient(135deg, rgba(255, 255, 255, 0.8) 0%, rgba(248, 250, 252, 0.8) 100%);
    border-radius: 15px;
    border: 1px solid rgba(255, 107, 53, 0.1);
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

.info-item::before {
    content: '';
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    width: 4px;
    background: linear-gradient(180deg, #ff6b35, #f7931e);
    transition: width 0.3s ease;
}

.info-item:hover {
    transform: translateX(5px);
    box-shadow: 0 5px 15px rgba(255, 107, 53, 0.2);
}

.info-item:hover::before {
    width: 8px;
}

.info-icon {
    width: 45px;
    height: 45px;
    background: linear-gradient(135deg, #ff6b35, #f7931e);
    border-radius: 12px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 1.1rem;
    box-shadow: 0 4px 12px rgba(255, 107, 53, 0.3);
    transition: all 0.3s ease;
}

.info-item:hover .info-icon {
    transform: rotate(5deg) scale(1.1);
    box-shadow: 0 6px 20px rgba(255, 107, 53, 0.4);
}

.info-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 5px;
}

.info-label {
    font-size: 0.85rem;
    color: #64748b;
    font-weight: 500;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.info-value {
    font-size: 1rem;
    color: #1e293b;
    font-weight: 600;
}

.card-data-section {
    margin-bottom: 20px;
    padding: 20px;
    background: linear-gradient(135deg, rgba(255, 107, 53, 0.05) 0%, rgba(247, 147, 30, 0.05) 100%);
    border-radius: 15px;
    border: 1px solid rgba(255, 107, 53, 0.1);
}

.data-header {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 15px;
    color: #ff6b35;
    font-weight: 600;
    font-size: 1rem;
}

.data-header i {
    font-size: 1.1rem;
    animation: iconPulse 2s infinite;
}

.data-grid {
    display: grid;
    gap: 10px;
}

.data-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 15px;
    background: rgba(255, 255, 255, 0.7);
    border-radius: 10px;
    border: 1px solid rgba(255, 107, 53, 0.1);
    transition: all 0.3s ease;
}

.data-item:hover {
    background: rgba(255, 255, 255, 0.9);
    transform: translateX(5px);
    box-shadow: 0 3px 10px rgba(255, 107, 53, 0.15);
}

.data-key {
    font-weight: 600;
    color: #475569;
    font-size: 0.9rem;
}

.data-value {
    color: #1e293b;
    font-weight: 500;
    text-align: right;
}

.card-actions-section {
    padding-top: 20px;
    border-top: 2px solid rgba(255, 107, 53, 0.1);
    display: flex;
    justify-content: center;
}

.modern-alert {
    padding: 20px;
    border-radius: 15px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-weight: 500;
    margin: 20px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.modern-alert-warning {
    background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
    color: #92400e;
    border: 1px solid #f59e0b;
}

.modern-alert i {
    font-size: 1.2rem;
    animation: iconPulse 2s infinite;
}

/* تحسينات للشاشات الصغيرة */
@media (max-width: 768px) {
    .modern-requests-table-container {
        border-radius: 15px;
        margin: 10px 0;
    }
    
    .modern-requests-th {
        padding: 15px 8px;
        font-size: 12px;
        
    }
    
    .modern-requests-body td {
        padding: 12px 8px;
        font-size: 12px;
    }
    
    .modern-requests-body td img {
        max-width: 60px !important;
        max-height: 45px !important;
    }
    
    .modern-requests-body .btn {
        padding: 6px 12px;
        font-size: 10px;
    }
    
    .modern-cards-container {
        grid-template-columns: 1fr;
        gap: 20px;
        padding: 15px;
    }
    
    .modern-card-header {
        padding: 15px;
    }
    
    .modern-card-body {
        padding: 20px;
    }
    
    .card-header-content {
        gap: 10px;
    }
    
    .card-id-badge,
    .card-type-badge {
        padding: 6px 12px;
        font-size: 0.8rem;
    }
    
    .info-icon {
        width: 40px;
        height: 40px;
        font-size: 1rem;
    }
}

@media (max-width: 480px) {
    .modern-cards-container {
        padding: 10px;
        gap: 15px;
    }
    
    .modern-rent-card {
        border-radius: 15px;
    }
    
    .modern-card-header {
        padding: 12px;
    }
    
    .modern-card-body {
        padding: 15px;
    }
    
    .card-header-content {
        flex-direction: column;
        gap: 8px;
        align-items: flex-start;
    }
    
    .info-item {
        padding: 12px;
    }
    
    .info-icon {
        width: 35px;
        height: 35px;
        font-size: 0.9rem;
    }
    
    .card-data-section {
        padding: 15px;
    }
}

/* تأثيرات إضافية للتفاعل */
.modern-requests-table-container:hover {
    box-shadow: 0 25px 50px rgba(0,0,0,0.15);
    transform: translateY(-2px);
}

.table-responsive {
    border-radius: 20px;
}

/* تحسين شكل التبويبات */
.nav-tabs {
    border: none;
    margin-bottom: 30px;
}

.nav-tabs .nav-link {
    border: none;
    border-radius: 25px;
    padding: 12px 30px;
    margin: 0 5px;
    background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    color: #6c757d;
    font-weight: 600;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(0,0,0,0.1);
}

.nav-tabs .nav-link:hover {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
    color: white;
    transform: translateY(-2px);
    box-shadow: 0 8px 20px rgba(255,107,53,0.3);
}

.nav-tabs .nav-link.active {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
    color: white;
    box-shadow: 0 8px 20px rgba(255,107,53,0.3);
}

/* تحسين العنوان الرئيسي */
h2.mb-4 {
    background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%);
    -webkit-background-clip: text;
    -webkit-text-fill-color:#ff8c42;
    background-clip: text;
    font-weight: 700;
    text-align: center;
    margin-bottom: 30px;
    font-size: 2.5rem;
    text-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
</style>

<h2 class="mb-4">إدارة الطلبات</h2>
<div class="mb-3">
    <ul class="nav nav-tabs" id="ordersTabs">
        <li class="nav-item">
            <button class="nav-link active" id="tab-appointments" onclick="switchTab('appointments')">مواعيد المعاينة</button>
        </li>
        <li class="nav-item">
            <button class="nav-link" id="tab-rents" onclick="switchTab('rents')">طلبات التأجير</button>
        </li>
        <li class="nav-item">
            <button class="nav-link" id="tab-other" onclick="switchTab('other')">طلبات أخرى</button>
        </li>
    </ul>
</div>
<div id="ordersTabContent" class="mt-4"></div>

<!-- Modal للعرض أو الرد -->
<div class="modal fade" id="orderModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orderModalTitle"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body" id="orderModalContent"></div>
            <div class="modal-footer" id="orderModalFooter"></div>
        </div>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
let currentTab = 'appointments';
let appointments = [];
let rents = [];
let loading = false;
let pollingInterval = null; // متغير لإدارة المؤقت الزمني
const baseUrl = 'http://192.168.1.7:8000'; // غيّرها حسب سيرفرك

function switchTab(tab) {
    currentTab = tab;
    document.querySelectorAll('#ordersTabs .nav-link').forEach(btn => btn.classList.remove('active'));
    document.getElementById('tab-' + tab).classList.add('active');
    // عند التبديل، قم بالمسح والعرض من جديد
    document.getElementById('ordersTabContent').innerHTML = ''; 
    renderCurrentTab();
}

function renderCurrentTab(auto = false) {
    if (currentTab === 'appointments') {
        fetchAppointments(auto);
    } else if (currentTab === 'rents') {
        fetchRents(auto);
    } else {
        document.getElementById('ordersTabContent').innerHTML = "<div class='modern-alert modern-alert-warning'><i class='fas fa-info-circle'></i> لا يوجد محتوى بعد.</div>";
    }
}

// ----------- Tab 1: مواعيد المعاينة -----------
async function fetchAppointments(auto = false) {
    if (loading) return; // منع التحديثات المتداخلة
    loading = true;
    const token = localStorage.getItem('token');
    
    // إظهار علامة التحميل فقط في المرة الأولى
    const container = document.getElementById('ordersTabContent');
    if (!auto && !container.innerHTML) {
        container.innerHTML = `<div class="text-center py-5"><div class="spinner-border"></div></div>`;
    }

    try {
        const res = await fetch(`${baseUrl}/api/appointments`, {
            headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json' }
        });
        const data = await res.json();
        const newAppointments = Array.isArray(data.appointments) ? data.appointments : [];
        renderAppointments(newAppointments); // تمرير البيانات الجديدة مباشرة
        appointments = newAppointments; // تحديث القائمة المحلية بعد العرض
    } catch (e) {
        if (!auto) {
            container.innerHTML = `<div class="modern-alert modern-alert-danger">تعذر تحميل المواعيد!</div>`;
            console.error('خطأ في تحميل المواعيد:', e);
        }
    }
    loading = false;
}

function renderAppointments(newAppointments) {
    const container = document.getElementById('ordersTabContent');
    const tableContainer = container.querySelector('.modern-requests-table-container');

    // إذا لم يكن هناك جدول، قم بإنشائه بالكامل (الحالة الأولية)
    if (!tableContainer) {
        if (!newAppointments.length) {
            container.innerHTML = `<div class="modern-alert modern-alert-warning"><i class="fas fa-exclamation-triangle"></i> لا توجد مواعيد بعد.</div>`;
            return;
        }
        let html = `<div class="table-responsive modern-requests-table-container"><table class="table table-bordered align-middle modern-requests-table">
        <thead class="modern-requests-header">
            <tr>
                <th class="modern-requests-th"><i class="bi bi-hash me-2"></i>#</th>
                <th class="modern-requests-th"><i class="bi bi-house me-2"></i>العقار</th>
                <th class="modern-requests-th"><i class="bi bi-person me-2"></i>العميل</th>
                <th class="modern-requests-th"><i class="bi bi-tools me-2"></i>مقدم الخدمة</th>
                <th class="modern-requests-th"><i class="bi bi-calendar-event me-2"></i>الموعد</th>
                <th class="modern-requests-th" data-cell="status"><i class="bi bi-flag me-2"></i>الحالة</th>
                <th class="modern-requests-th"><i class="bi bi-chat-text me-2"></i>ملاحظات</th>
                <th class="modern-requests-th" data-cell="actions"><i class="bi bi-gear me-2"></i>إجراءات</th>
            </tr>
        </thead>
        <tbody class="modern-requests-body">
        </tbody></table></div>`;
        container.innerHTML = html;
    }
    
    const tableBody = container.querySelector('.modern-requests-body');
    const newIds = new Set(newAppointments.map(app => app.id));

    // إزالة الصفوف القديمة التي لم تعد موجودة
    tableBody.querySelectorAll('tr[data-id]').forEach(row => {
        const rowId = parseInt(row.dataset.id, 10);
        if (!newIds.has(rowId)) {
            row.remove();
        }
    });

    // تحديث وإضافة الصفوف الجديدة
    newAppointments.forEach(app => {
        let row = tableBody.querySelector(`tr[data-id='${app.id}']`);
        // التحقق مما إذا كان هناك تغيير في الحالة
        const existingApp = appointments.find(a => a.id === app.id);
        const hasChanged = !existingApp || existingApp.status !== app.status;

        if (!row) { // صف جديد، قم بإضافته
            const newRow = document.createElement('tr');
            newRow.dataset.id = app.id;
            newRow.innerHTML = `
                <td>${app.id}</td>
                <td>
                    <b>${app.property?.type ?? ''}</b>
                    <div>العنوان: ${app.property?.address ?? ''}</div>
                    <img src="${app.property?.image_url ?? ''}" style="max-width:80px;max-height:60px;" onerror="this.style.display='none'">
                </td>
                <td>${app.customer?.name ?? ''}<br>${app.customer?.phone ?? ''}</td>
                <td>${app.provider?.name ?? ''}<br>${app.provider?.phone ?? ''}</td>
                <td>${app.appointment_datetime}</td>
                <td data-cell="status">${getStatusLabel(app.status)}</td>
                <td>
                    <div>${app.note ?? ''}</div>
                    <div class="text-success">${app.admin_note ?? ''}</div>
                </td>
                <td data-cell="actions">${renderAppointmentActions(app)}</td>
            `;
            tableBody.appendChild(newRow);
        } else if (hasChanged) { // الصف موجود ولكن حالته تغيرت
            row.querySelector('[data-cell="status"]').innerHTML = getStatusLabel(app.status);
            row.querySelector('[data-cell="actions"]').innerHTML = renderAppointmentActions(app);
        }
    });
}

// ----------- Tab 2: طلبات التأجير -----------
async function fetchRents(auto = false) {
    if (loading) return; // منع التحديثات المتداخلة
    loading = true;
    const token = localStorage.getItem('token');

    const container = document.getElementById('ordersTabContent');
    if (!auto && !container.innerHTML) {
        container.innerHTML = `<div class="text-center py-5"><div class="spinner-border"></div></div>`;
    }
    
    try {
        const res = await fetch(`${baseUrl}/api/admin/service-requests/all`, {
            headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json' }
        });
        const data = await res.json();
        const allRequests = Array.isArray(data.all_requests) ? data.all_requests : [];
        const newRents = allRequests.filter(r => r.type === 'rent');
        renderRents(newRents); // تمرير البيانات الجديدة
        rents = newRents; // تحديث القائمة المحلية
    } catch (e) {
        if (!auto) {
            container.innerHTML = `<div class="modern-alert modern-alert-danger">تعذر تحميل طلبات التأجير!</div>`;
            console.error('خطأ في تحميل طلبات التأجير:', e);
        }
    }
    loading = false;
}

function renderRents(newRents) {
    const container = document.getElementById('ordersTabContent');
    let cardsContainer = container.querySelector('.modern-cards-container');

    // إذا لم تكن هناك حاوية للكروت، قم بإنشائها
    if (!cardsContainer) {
        if (!newRents.length) {
            container.innerHTML = `<div class="modern-alert modern-alert-warning"><i class="fas fa-exclamation-triangle"></i> لا توجد طلبات تأجير بعد.</div>`;
            return;
        }
        container.innerHTML = `<div class="modern-cards-container"></div>`;
        cardsContainer = container.querySelector('.modern-cards-container');
    }
    
    const newIds = new Set(newRents.map(r => r.id));

    // إزالة الكروت القديمة
    cardsContainer.querySelectorAll('.modern-rent-card[data-id]').forEach(card => {
        const cardId = parseInt(card.dataset.id, 10);
        if (!newIds.has(cardId)) {
            card.remove();
        }
    });

    // تحديث وإضافة الكروت الجديدة
    newRents.forEach(rent => {
        let card = cardsContainer.querySelector(`.modern-rent-card[data-id='${rent.id}']`);
        const existingRent = rents.find(r => r.id === rent.id);
        const hasChanged = !existingRent || existingRent.status !== rent.status;

        const cardHtml = `
            <div class="modern-card-header">
                <div class="card-header-content">
                    <div class="card-id-badge"><i class="fas fa-hashtag"></i><span>${rent.id}</span></div>
                    <div class="card-type-badge"><i class="fas fa-tag"></i><span>${rent.type === 'rent' ? 'تأجير' : rent.type}</span></div>
                </div>
                <div class="card-status" data-cell="status">${getStatusLabel(rent.status)}</div>
            </div>
            <div class="modern-card-body">
                <div class="card-info-section">
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-user"></i></div>
                        <div class="info-content"><span class="info-label">المستخدم</span><span class="info-value">${rent.user?.name ?? 'غير محدد'}</span></div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-phone"></i></div>
                        <div class="info-content"><span class="info-label">رقم الهاتف</span><span class="info-value">${rent.user?.phone ?? 'غير محدد'}</span></div>
                    </div>
                    <div class="info-item">
                        <div class="info-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div class="info-content"><span class="info-label">المحافظة</span><span class="info-value">${rent.governorate ?? 'غير محدد'}</span></div>
                    </div>
                </div>
                ${Object.keys(rent.request_data || {}).length > 0 ? `
                <div class="card-data-section">
                    <div class="data-header"><i class="fas fa-info-circle"></i><span>تفاصيل الطلب</span></div>
                    <div class="data-grid">
                        ${Object.entries(rent.request_data || {}).map(([key, value]) => `
                            <div class="data-item"><span class="data-key">${key}</span><span class="data-value">${value}</span></div>
                        `).join('')}
                    </div>
                </div>` : ''}
                <div class="card-actions-section" data-cell="actions">${renderRentActions(rent)}</div>
            </div>
        `;

        if (!card) { // كارت جديد
            const newCard = document.createElement('div');
            newCard.className = 'modern-rent-card';
            newCard.dataset.id = rent.id;
            newCard.innerHTML = cardHtml;
            cardsContainer.appendChild(newCard);
        } else if (hasChanged) { // تحديث الكارت الموجود
            card.querySelector('[data-cell="status"]').innerHTML = getStatusLabel(rent.status);
            card.querySelector('[data-cell="actions"]').innerHTML = renderRentActions(rent);
        }
    });
}


// --- دوال المساعدة لم تتغير ---
function getStatusLabel(status) {
    switch (status) {
        case 'pending': return `<span class="badge bg-secondary">قيد المراجعة</span>`;
        case 'admin_approved':
        case 'approved': 
            return `<span class="badge bg-success">تمت الموافقة</span>`;
        case 'admin_rejected': return `<span class="badge bg-danger">مرفوض</span>`;
        default: return `<span class="badge bg-light">${status}</span>`;
    }
}

function renderAppointmentActions(app) {
    if (app.status === 'pending') {
        return `<button type="button" class="btn btn-success btn-sm" onclick="updateAppointmentStatus(${app.id}, 'admin_approved')">قبول</button>
        <button type="button" class="btn btn-danger btn-sm ms-1" onclick="updateAppointmentStatus(${app.id}, 'admin_rejected')">رفض</button>`;
    }
    return `<span class="text-muted">-</span>`;
}

async function updateAppointmentStatus(id, status) {
    const token = localStorage.getItem('token');
    const admin_note = status === 'admin_approved' ? 'تمت الموافقة على الموعد من الإدارة' : 'تم رفض الموعد من الإدارة';
    let res = await fetch(`${baseUrl}/api/appointments/${id}/status`, {
        method: 'PUT',
        headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, admin_note })
    });
    if (res.ok) {
        // تحديث البيانات تلقائياً سيقوم بعرض التغيير
        const updatedApp = appointments.find(a => a.id === id);
        if(updatedApp) {
            updatedApp.status = status;
            updatedApp.admin_note = admin_note;
            renderAppointments(appointments);
        }
    } else {
        alert('حدث خطأ أثناء تحديث الحالة!');
    }
}

function renderRentActions(rent) {
    if (rent.status === 'pending') {
        return `<button type="button" class="btn btn-success btn-sm" onclick="approveRent(${rent.id})">قبول</button>
            <button type="button" class="btn btn-danger btn-sm ms-1" onclick="rejectRent(${rent.id})">رفض</button>`;
    }
    return `<span class="text-muted">${rent.status === 'approved' ? "تمت الموافقة" : "-"}</span>`;
}

async function approveRent(id) {
    const token = localStorage.getItem('token');
    let res = await fetch(`${baseUrl}/api/admin/service-requests/${id}/approve`, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json', 'Content-Type': 'application/json' }
    });
    if (res.ok) {
        const updatedRent = rents.find(r => r.id === id);
        if(updatedRent) {
            updatedRent.status = 'approved';
            renderRents(rents);
        }
    } else {
        alert('خطأ أثناء قبول الطلب');
    }
}

async function rejectRent(id) {
    const token = localStorage.getItem('token');
    let res = await fetch(`${baseUrl}/api/admin/service-requests/${id}/reject`, {
        method: 'POST',
        headers: { 'Authorization': 'Bearer ' + token, 'Accept': 'application/json', 'Content-Type': 'application/json' }
    });
    if (res.ok) {
        rents = rents.filter(rent => rent.id !== id);
        renderRents(rents);
    } else {
        alert('خطأ أثناء رفض الطلب');
    }
}


// ---------- دوال التحديث التلقائي ----------
function startPolling() {
    if (pollingInterval) clearInterval(pollingInterval);
    pollingInterval = setInterval(() => {
        if (!loading) {
            renderCurrentTab(true); // true لتجنب رسائل التحميل
        }
    }, 5000); // كل 5 ثوانٍ
}

function stopPolling() {
    if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
    }
}

// ---------- بدء التشغيل ----------
document.addEventListener('DOMContentLoaded', function() {
    switchTab('appointments');
    startPolling();
});

window.addEventListener('beforeunload', function() {
    stopPolling();
});

</script>
@endsection